### time series analysis
### using the death/recovery series to estimate the risk of death

rm(list = ls())

library(Rcpp)
library(RcppParallel)
library(chron)
########
# set link
setwd("/Users/timtsang/Dropbox/2019nCoV/casedef/program_rcpp")
setwd("Z:/2019nCoV/casedef/program_rcpp")
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


########################################################################
data <- read.csv("Epidemic_curve_China.csv")
data <- data[-82,]
data1 <- as.matrix(data[,c("wuhan.confirmed","hubeiexclwuhan.confirmed","chinaexclhubei.confirmed","china.reported")] )


sourceCpp("nov.cpp")
# 1-2 incubation parameter
# 3-4 onset to reporting
# 5-8 varinace for normal
# 9-11 change from v1 to v2, v2 to v4, v4 to v5
# 12-14 intercept
# 15-17 growth rate
# 18-20 reduction of intervention for continuous effect

# 11/19/2019

para <- c(1.43,0.66,5 , 4,0.1,0.1,0.1,0.1,rep(0,3),rep(0,3),rep(0.1,3),rep(-0.15,3))


test <- loglik(data1,para)
sum(test)




move <- rep(1,21)
move[c(1:2,7:8)] <- 0
sigma <- (abs(para)+0.1)/5


aaaaa1 <- Sys.time()
tt <- mcmc(data1,para,200000,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)


id <- runif(1,0,1)
inc <- 10000+1:10000*10
z1 <- para_summary((tt[[1]][inc,]),4,3,1)
plot(tt[[2]][inc,1])
print(z1)
write.csv(z1,paste("mcmc_summary_",id,".csv",sep=""))

save.image(paste("image_",id,".Rdata",sep=""))

load("/Users/timtsang/Dropbox/2019nCoV/casedef/program_rcpp/image_0.729555189609528.Rdata")
sourceCpp("nov.cpp")
gg <- pred(data1,z1[,1])
sum(gg[[4]][,c(5,10,15)])

write.csv(gg[[4]],"/Users/timtsang/Dropbox/2019nCoV/casedef/summary/pred.csv",row.names=F)

para  <- z1[,1]
para[18:20] <- 0
gg <- pred(data1,para )

write.csv(gg[[4]],"/Users/timtsang/Dropbox/2019nCoV/casedef/summary/pred2.csv",row.names=F)

## compute
pred2 <- matrix(NA,10000,4)
paramat <- tt[[1]][inc,]
for (i in 1:10000){
  gg <- pred(data1,paramat[i,])[[4]] 
  pred2[i,] <- c(colSums(gg[1:30,c(5,10,15)]),sum(colSums(gg[,c(5,10,15)])))
}

para_summary(pred2,4,3,1)

## compute
pred2 <- matrix(NA,10000,4)
paramat <- tt[[1]][inc,]
for (i in 1:10000){
  para  <- paramat[i,]
  para[18:20] <- 0
  gg <- pred(data1,para)[[4]] 
  pred2[i,] <- c(colSums(gg[,c(5,10,15)]),sum(colSums(gg[,c(5,10,15)])))
}

para_summary(pred2,4,3,1)


## compute
pred3 <- matrix(NA,10000,2)
paramat <- tt[[1]][inc,]
for (i in 1:10000){
  para  <- paramat[i,]
  pred3[i,1] <- sum((dgamma(1:200,para[3],1/para[4]))*0:199)
  pred3[i,2] <- sum((qgamma(0.95,para[3],1/para[4])))
}

para_summary(pred3,4,3,1)

#layout(matrix(1,nrow=1,byrow=T))
#plot(log10(data1[,1]))
#points(gg[[2]][,1],col="Red")
#lines(log10(gg[[4]][,1]),col="blue")


#plot(data1[,4])
#points(rowSums(gg[[5]]),col="red")
