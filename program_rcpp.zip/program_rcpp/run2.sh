#!/bin/bash
#SBATCH --job-name='zika'
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64gb
#SBATCH --time=96:00:00
#SBATCH --account=epi
#SBATCH --qos=epi-b
#SBATCH --partition=hpg2-compute

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript nov.r 

date
